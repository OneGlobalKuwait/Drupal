<?php

namespace Drupal\commerce_ogcheckout\Plugin\Commerce\PaymentGateway;

use Drupal\commerce_payment\Plugin\Commerce\PaymentGateway\OffsitePaymentGatewayBase;
use Drupal\commerce_payment\Entity\PaymentInterface;
use Drupal\commerce_payment\Exception\PaymentGatewayException;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\commerce_order\Entity\OrderInterface;
use Symfony\Component\HttpFoundation\Request;
define("TOTALCHANNELS", 10);

/**
 * Provides the ogcheckout Express Checkout payment gateway.
 *
 * @CommercePaymentGateway(
 *   id = "og_checkout",
 *   label = @Translation("Og Checkout"),
 *   display_label = @Translation("Og Checkout"),
 *    forms = {
 *     "offsite-payment" = "Drupal\commerce_ogcheckout\PluginForm\OgCheckoutForm",
 *   },
 * )
 */

class OgCheckout extends OffsitePaymentGatewayBase{

/**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return [
        'keyconfig' => array(
            'merchantcode' => '',
            'auth_key' => '',
            'secret' => '',
            'api_url' => '',
            'language' => '',
            'tunnel' => ''
        ) ,
        'paymentmethods' => array(
            'channels' => 'single',
            'multicurrencycode' => '',
			'multicurrencycurrency' => '',
            'single' => array(),
        )
    ]; //+ parent::defaultConfiguration();
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildConfigurationForm($form, $form_state);
    $form['display_label']['#access'] = FALSE;

	$form['keyconfig'] = array(
      '#type' => 'fieldset',
      '#title' => t('Keys & URLs Configuration'),
    );
    $form['keyconfig']['merchantcode'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Merchant Name'),
      '#default_value' => $this->configuration['keyconfig']['merchantcode'],
      '#required' => TRUE,
    ];
    $form['keyconfig']['auth_key'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Authentication Key'),
      '#default_value' => $this->configuration['keyconfig']['auth_key'],
      '#required' => TRUE,
    ];
	$form['keyconfig']['secret'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Secret Key'),
      '#default_value' => $this->configuration['keyconfig']['secret'],
      '#required' => TRUE,
    ];
    $form['keyconfig']['api_url'] = [
      '#type' => 'textfield',
      '#title' => $this->t('EndPoint URL'),
      '#default_value' => $this->configuration['keyconfig']['api_url'],
      '#required' => TRUE,
    ];
	$form['keyconfig']['language'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Payment Language'),
      '#default_value' => $this->configuration['keyconfig']['language'],
      '#required' => TRUE,
    ];
	$form['keyconfig']['tunnel'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Payment Tunnel'),
      '#default_value' => $this->configuration['keyconfig']['tunnel'],
      '#required' => FALSE,
    ];
	$form['paymentmethods'] = array(
        '#type' => 'fieldset',
        '#title' => t('Payment Methods Configuration') ,
        'channels' => array(
            '#type' => 'radios',
            '#title' => t('Channel') ,
            '#default_value' => $this->configuration['paymentmethods']['channels'],
            '#options' => array(
                'single' => t('Customize Your Payment Form') ,
                'multi' => t('Og Checkout Payment Form')
            ) ,
        ) ,
        'multicurrencycode' => array(
            '#type' => 'textfield',
            '#title' => t('Payment Method') ,
            '#default_value' => $this->configuration['paymentmethods']['multicurrencycode'],
            '#description' => t('Refer to Documentation') ,
            '#states' => array(
                'visible' => array(
                    ':input[name="configuration[og_checkout][paymentmethods][channels]"]' => ['value' => 'multi'],
                ) ,
                'required' => array(
                    ':input[name="configuration[og_checkout][paymentmethods][channels]"]' => ['value' => 'multi'],
                ) ,
            ) ,
            // '#element_validate' => array(
                // 'commerce_ogcheckout_element_validate'
            // )
        ) ,
		'multicurrencycurrency' => array(
            '#type' => 'textfield',
            '#title' => t('Payment Currency') ,
            '#default_value' => $this->configuration['paymentmethods']['multicurrencycurrency'],
            '#description' => t('Leave this field blank when you use "all" parameter in Payment Method.') ,
            '#states' => array(
                'visible' => array(
                    ':input[name="configuration[og_checkout][paymentmethods][channels]"]' => ['value' => 'multi'],
                ) ,
            ) ,
        ) ,
        'single' => array()
    );
    for ($i = 0;$i < TOTALCHANNELS ;$i++) {
        $form['paymentmethods']['single'][$i] = array(
            '#type' => 'fieldset',
            '#title' => t('Payment Method @count', array('@count'=> ($i+1))),
            '#collapsible' => true,
            '#states' => ['visible' => [':input[name="configuration[og_checkout][paymentmethods][channels]"]' => ['value' => 'single'],
            ],
            ],
            'name' => array(
                '#type' => 'textfield',
                '#title' => t('Payment Channel') ,
                '#default_value' => (isset($this->configuration['paymentmethods']['single'][$i])) ? $this->configuration['paymentmethods']['single'][$i]['name'] : '',
                '#description' => t('Example: Credit Card, Debit Card etc') ,
                '#states' => ['visible' => [':input[name="configuration[og_checkout][paymentmethods][channels]"]' => ['value' => 'single'],
                ],
                'required' => [':input[name="configuration[og_checkout][paymentmethods][single][' . $i . '][code]"]' => ['filled' => true],
                ],
                ],
                // '#element_validate' => array(
                    // 'commerce_ogcheckout_element_validate'
                // )
            ) ,
            'code' => array(
                '#type' => 'textfield',
                '#title' => t('Channel Code'),
                '#default_value' => (isset($this->configuration['paymentmethods']['single'][$i])) ? $this->configuration['paymentmethods']['single'][$i]['code'] : '',
                '#states' => ['visible' => [':input[name="configuration[og_checkout][paymentmethods][channels]"]' => ['value' => 'single'],
                ],
                'required' => [':input[name="configuration[og_checkout][paymentmethods][single][' . $i . '][name]"]' => ['filled' => true],
                ],
                ],
                // '#element_validate' => array(
                    // 'commerce_ogcheckout_element_validate'
                // )
            ),
			'currency' => array(
                '#type' => 'textfield',
                '#title' => t('Currency Code') ,
                '#default_value' => (isset($this->configuration['paymentmethods']['single'][$i])) ? $this->configuration['paymentmethods']['single'][$i]['currency'] : '',
				'#states' => ['visible' => [':input[name="configuration[og_checkout][paymentmethods][channels]"]' => ['value' => 'single'],
                ],
				],
            )
        );
    }
	$form['paymentmethods']['single'][0]['#required'] = true;
    $form['paymentmethods']['single'][0]['name']['#states']['required'] = array(
        ':input[name="configuration[og_checkout][paymentmethods][channels]"]' => array(
            'value' => 'single'
        )
    );

    $form['paymentmethods']['single'][0]['code']['#states']['required'] = array(
        ':input[name="configuration[og_checkout][paymentmethods][channels]"]' => array(
            'value' => 'single'
        )
    );
    return $form;
  }
  
  /**
   * {@inheritdoc}
   */
  public function validateConfigurationForm(array &$form, FormStateInterface $form_state) {
	  
  } 
  /**
   * {@inheritdoc}
   */
  public function getRedirectUrl() {
    if ($this->getMode() == 'test') {
      return 'https://pay-it.mobi/globalpayit/pciglobal/WebForms/Payitcheckoutservice2.aspx';
    }
    else {
      return 'https://pay-it.mobi/globalpayit/pciglobal/WebForms/Payitcheckoutservice2.aspx';
    }
  }
  /**
   * {@inheritdoc}
   */
  public function submitConfigurationForm(array &$form, FormStateInterface $form_state) {
    parent::submitConfigurationForm($form, $form_state);
    if (!$form_state->getErrors()) {
      $values = $form_state->getValue($form['#parents']);
      $this->configuration['display_label'] = 'Og Checkout';
      $this->configuration['keyconfig']['merchantcode'] = $values['keyconfig']['merchantcode'];
      $this->configuration['keyconfig']['auth_key'] = $values['keyconfig']['auth_key'];
      $this->configuration['keyconfig']['secret'] = $values['keyconfig']['secret'];
      $this->configuration['keyconfig']['api_url'] = $values['keyconfig']['api_url'];
	  $this->configuration['keyconfig']['language'] = $values['keyconfig']['language'];
      $this->configuration['keyconfig']['tunnel'] = $values['keyconfig']['tunnel'];
	  $this->configuration['keyconfig']['currency'] = $values['keyconfig']['currency'];
	  $this->configuration['paymentmethods']['channels'] = $values['paymentmethods']['channels'];
	  $this->configuration['paymentmethods']['multicurrencycode'] = $values['paymentmethods']['multicurrencycode'];
	  $this->configuration['paymentmethods']['multicurrencycurrency'] = $values['paymentmethods']['multicurrencycurrency'];
	  if(!empty($values['paymentmethods']['single']) && ($values['paymentmethods']['channels'] == 'single')) {
		  $channelconfigs = array();
		  foreach($values['paymentmethods']['single'] as $key=>$val){
		      $channelconfig = array();
			  $channelconfig['name'] = $val['name'];
			  $channelconfig['code'] = $val['code'];
			  $channelconfig['currency'] = $val['currency'];
			  if(!empty($channelconfig['code'])){
			    $channelconfigs[] = $channelconfig;
			  }
		  }
		  $this->configuration['paymentmethods']['single'] = $channelconfigs;
	  }
    }
  }
 
  /**
   * {@inheritdoc}
   */
  public function onReturn(OrderInterface $order, Request $request) {
	$response = array();
	$configuration = $this->getConfiguration();
	$trackid = $request->query->get('trackid');
    $result = $request->query->get('result');
	$refid = $request->query->get('refid');
    $errormessage = $request->query->get('errormessage');
    $hash = $request->query->get('Hash');
    $secret_key = $configuration['keyconfig']['secret'];
	$order_trackid = $order->getData('commerce_ogcheckout')['trackID'];
	$dataToComputeHash = 'trackid=' . $trackid . '&result=' . $result . '&refid=' . $refid;
    
	if ($hash!=OgCheckout::commerce_ogcheckout_hash($dataToComputeHash, $secret_key)) {
	  throw new PaymentGatewayException('Invalid Hash Detected');
    }
	if ($trackid!=$order_trackid) {
      throw new PaymentGatewayException('Invalid Order Detected');
    }
	switch ($result) {
	  case 'CAPTURED':
        $payment_storage = $this->entityTypeManager->getStorage('commerce_payment');
        $payment = $payment_storage->create([
          'state' => 'completed',
          'amount' => $order->getTotalPrice(),
          'payment_gateway' => $this->entityId,
          'order_id' => $order->id(),
          'test' => $this->getMode() == 'test',
          'remote_id' => $trackid,
          'remote_state' => $result,
          'authorized' => $this->time->getRequestTime(),
        ]);
        $payment->save();
        drupal_set_message($this->t('Your payment was successful'));
        break;
	  default:
	    throw new PaymentGatewayException('The transaction has been '.$result);
        break;
	}
  }
  

  public function gentoken_validate(PaymentInterface $payment, $extra) {
	
	$configuration = $this->getConfiguration();
	
	$channel = ($configuration['paymentmethods']['channels'] == 'single') ? 'single' : 'multi'; 
	$pc = $extra['pc'];
	$currency = 'KWD';

	if ($channel == 'single') {
		foreach ($configuration['paymentmethods']['single'] as $key) {
	        if($key['code'] == $pc) {
				$currency = $key['currency'];
				break;
			}
		}
	}
	else {
		if(strcasecmp($pc,'all') == 0) {
		  $currency = $payment->getAmount()->getCurrencyCode();
		} else if(!empty($configuration['paymentmethods']['multicurrencycurrency'])) {
		  $currency = $configuration['paymentmethods']['multicurrencycurrency'];
		}
	}
	$amount = (float)$payment->getAmount()->getNumber();
	$language = $configuration['keyconfig']['language'];
    $tunnel = $configuration['keyconfig']['tunnel'];
    $merchantCode = $configuration['keyconfig']['merchantcode'];
    $secret_key = $configuration['keyconfig']['secret'];
    $authKey = $configuration['keyconfig']['auth_key'];
    $time_stamp = date('Y/m/d h:i:s A', time());
    $referenceID = OgCheckout::commerce_ogcheckout_generate_referenceid(15);
    $sourceCurrency = ($currency == $payment->getAmount()->getCurrencyCode()) ? '' : $payment->getAmount()->getCurrencyCode();
	$userReference = 0;
    $merchantResponseUrl = $extra['return_url'];
    $dataToComputeHash = $amount . $authKey . $currency . $merchantCode . $pc . $referenceID . $sourceCurrency . $time_stamp . $tunnel . $userReference;
	
	$og_data = [
        'merchantCode' => $merchantCode,
        'authKey' => $authKey,
        'currency' => $currency,
        'pc' => $pc,
        'tunnel' => $tunnel,
        'amount' => $amount,
        'doConvert' => ("" == $sourceCurrency) ? 'N' : 'Y',
        'sourceCurrency' => $sourceCurrency,
        'referenceID' => $referenceID,
        'timeStamp' => $time_stamp,
        'userReference' => $userReference,
        'language' => $language,
        'callbackURL' => $merchantResponseUrl,
        'hash' => OgCheckout::commerce_ogcheckout_hash($dataToComputeHash, $secret_key),
    ];
	$clientFactory = \Drupal::service('http_client_factory');
	$client = $clientFactory->fromOptions(['verify' => FALSE]);
	
	$response = $client->post($configuration['keyconfig']['api_url'], [
      'json' => $og_data,
    ]);
	  
	$og_response = json_decode($response->getBody(), TRUE);
	return $og_response;
  }
  
  function commerce_ogcheckout_generate_referenceid($digits_needed) {
    $random_number = ''; // set up a blank string
    $count = 0;
    while ($count < $digits_needed) {
        $random_digit = mt_rand($count == 0 ? 1 : 0, 9);
        $random_number .= $random_digit;
        $count++;
    }
    return intval($random_number);
  }

  function commerce_ogcheckout_hash($data, $key) {
    $hash = strtoupper(hash_hmac("sha256", $data, $key));
    return $hash;
  }

}
